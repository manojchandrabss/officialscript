addhost
=======

Simple script to add new apache2 host in Ubuntu

How to use
----------

Set the script executable:

```
sudo chmod +x ./addhost.sh
```
and execute it. Set the new host name as the first param:
```
sudo ./addhost.sh testhost.loc
```

After that try to open the new host in browser:
```
links testhost.loc
```
